ALTER TABLE `bot_config` ADD `enableFollows` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `bot_config` ADD `enableLikes` boolean DEFAULT true NOT NULL;